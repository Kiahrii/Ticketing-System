<?php
include 'config.php';

// Debug
error_log("📨 Received: " . print_r($_POST, true));

if (isset($_POST['employee_id']) && isset($_POST['user_type']) && isset($_POST['user_status'])) {
    $employee_id = (int)$_POST['employee_id'];
    $user_type = $_POST['user_type'];
    $user_status = $_POST['user_status'];
    
    $sql = "UPDATE user_info SET user_type = ?, user_status = ? WHERE employee_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $user_type, $user_status, $employee_id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Updated successfully!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'DB Error: ' . $stmt->error]);
    }
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Missing data']);
}

$conn->close();
?>