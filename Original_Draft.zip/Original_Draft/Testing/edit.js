// edit.js
function saveChanges(rowId) {
    const row = document.querySelector(`tr[data-id="${rowId}"]`);
    const userType = row.querySelector('.user-type').value;
    const userStatus = row.querySelector('.user-status').value;
    
    console.log('Saving:', {rowId, userType, userStatus});
    
    const formData = new FormData();
    formData.append('employee_id', rowId);
    formData.append('user_type', userType);
    formData.append('user_status', userStatus);
    
    fetch('update_user.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        console.log('Response:', data);
        if (data.success) {
            alert('Saved!');
        } else {
            alert('Error: ' + data.message);
        }
    })
    .catch(error => console.error('Error:', error));
}

function cancelChanges(rowId) {
    console.log('Cancel changes for:', rowId);
    // Reload the page to reset changes
    location.reload();
}