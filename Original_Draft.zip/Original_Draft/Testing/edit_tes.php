<?php
// TEST FILE: edit_test.php
include 'config.php';

// Handle the update right in this file
if ($_POST['action'] ?? '' === 'update') {
    $employee_id = (int)$_POST['employee_id'];
    $user_type = $_POST['user_type'];
    $user_status = $_POST['user_status'];
    
    $sql = "UPDATE user_info SET user_type = ?, user_status = ? WHERE employee_id = ?";
    $stmt = $connection->prepare($sql);
    $stmt->bind_param("ssi", $user_type, $user_status, $employee_id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Updated!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'DB Error']);
    }
    $stmt->close();
    exit;
}

// Normal page display
$user_result = mysqli_query($connection, "SELECT *, CONCAT(first_name,' ',last_name) as name FROM user_info");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Users</title>
    <style>
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 8px; }
        .save-btn { background: green; color: white; padding: 5px 10px; border: none; cursor: pointer; }
    </style>
</head>
<body>
    <h1>Edit Users TEST</h1>
    <table>
        <thead>
            <tr><th>ID</th><th>Name</th><th>User Type</th><th>User Status</th><th>Action</th></tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($user_result)): ?>
            <tr data-id="<?= $row['employee_id'] ?>">
                <td><?= $row['employee_id'] ?></td>
                <td><?= $row['name'] ?></td>
                <td>
                    <select class="user-type">
                        <option value="admin" <?= $row['user_type'] == 'admin' ? 'selected' : '' ?>>Admin</option>
                        <option value="requester" <?= $row['user_type'] == 'requester' ? 'selected' : '' ?>>Requester</option>
                    </select>
                </td>
                <td>
                    <select class="user-status">
                        <option value="active" <?= $row['user_status'] == 'active' ? 'selected' : '' ?>>Active</option>
                        <option value="inactive" <?= $row['user_status'] == 'inactive' ? 'selected' : '' ?>>Inactive</option>
                    </select>
                </td>
                <td>
                    <button type="button" class="save-btn" onclick="saveChanges(<?= $row['employee_id'] ?>)">SAVE</button>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <script>
    function saveChanges(employeeId) {
        console.log('Saving:', employeeId);
        
        const row = document.querySelector(`tr[data-id="${employeeId}"]`);
        const userType = row.querySelector('.user-type').value;
        const userStatus = row.querySelector('.user-status').value;
        
        // Send to THIS SAME FILE
        fetch('<?= $_SERVER['PHP_SELF'] ?>', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `action=update&employee_id=${employeeId}&user_type=${userType}&user_status=${userStatus}`
        })
        .then(response => {
            console.log('Response status:', response.status);
            return response.json();
        })
        .then(data => {
            console.log('Success:', data);
            alert(data.success ? '✅ Saved!' : '❌ Error: ' + data.message);
        })
        .catch(error => {
            console.error('Fetch failed:', error);
            alert('❌ Network error - check console');
        });
    }
    </script>
</body>
</html>