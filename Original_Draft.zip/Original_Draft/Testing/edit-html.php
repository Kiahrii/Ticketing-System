<?php
include 'config.php';
$user_result = mysqli_query($connection, "SELECT *, CONCAT(first_name,' ',last_name) as name FROM user_info");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Users</title>
    <style>
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        select { padding: 5px; width: 100%; }
        .save-btn { background: green; color: white; padding: 5px 10px; border: none; cursor: pointer; }
        .cancel-btn { background: red; color: white; padding: 5px 10px; border: none; cursor: pointer; }
    </style>
</head>
<body>
    <h1>Edit Users</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th><th>Name</th><th>Employee No.</th><th>Department</th><th>Username</th>
                <th>User Type</th><th>User Status</th><th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($user_result)): ?>
            <tr data-id="<?= $row['employee_id'] ?>">
                <td><?= $row['employee_id'] ?></td>
                <td><?= $row['name'] ?></td>
                <td><?= $row['emp_no'] ?></td>
                <td><?= $row['department'] ?></td>
                <td><?= $row['username'] ?></td>
                <td>
                    <select class="user-type">
                        <option value="admin" <?= $row['user_type'] == 'admin' ? 'selected' : '' ?>>Admin</option>
                        <option value="requester" <?= $row['user_type'] == 'requester' ? 'selected' : '' ?>>Requester</option>
                    </select>
                </td>
                <td>
                    <select class="user-status">
                        <option value="active" <?= $row['user_status'] == 'active' ? 'selected' : '' ?>>Active</option>
                        <option value="inactive" <?= $row['user_status'] == 'inactive' ? 'selected' : '' ?>>Inactive</option>
                    </select>
                </td>
                <td>
                    <button type="button" class="save-btn" onclick="saveChanges(<?= $row['employee_id'] ?>)">Save</button>
                    <button type="button" class="cancel-btn" onclick="cancelChanges(<?= $row['employee_id'] ?>)">Cancel</button>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <script>
    // TEST: Check if script loads
    console.log('🔥 JavaScript loaded!');

    function saveChanges(employeeId) {
        console.log('💾 Saving employee:', employeeId);
        
        const row = document.querySelector(`tr[data-id="${employeeId}"]`);
        const userType = row.querySelector('.user-type').value;
        const userStatus = row.querySelector('.user-status').value;
        
        console.log('📊 Data:', {employeeId, userType, userStatus});

        // Send to PHP
        fetch('update_user.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `employee_id=${employeeId}&user_type=${userType}&user_status=${userStatus}`
        })
        .then(response => response.json())
        .then(data => {
            console.log('✅ Response:', data);
            if (data.success) {
                alert('✅ Saved successfully!');
            } else {
                alert('❌ Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('❌ Fetch error:', error);
            alert('❌ Network error');
        });
    }

    function cancelChanges(employeeId) {
        console.log('🚫 Cancel:', employeeId);
        location.reload();
    }
    </script>
</body>
</html>