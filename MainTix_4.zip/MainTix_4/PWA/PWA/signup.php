<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account - MainTix</title>
    <link rel="stylesheet" href="./dist/assets/css/signup.css">
</head>
<body>
    <div class="create-account-container">
        <div class="logo">MainTix</div>
        <form id="createAccountForm" action="dist/database/register.php" method="POST">
            <div class="form-row">
                <div class="form-group">
                    <label for="firstName">First Name <span style="color: red;">*</span></label>
                    <input type="text" id="firstName" name="first_name" placeholder="Enter first name" required>
                </div>
                
                <div class="form-group">
                    <label for="lastName">Last Name <span style="color: red;">*</span></label>
                    <input type="text" id="lastName" name="last_name" placeholder="Enter last name" required>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="tinNo">Employee Number <span style="color: red;">*</span></label>
                    <input type="text" id="tinNo" name="emp_no" placeholder="Enter Employee Number" required maxlength="11">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="department">Department <span style="color: red;">*</span></label>
                    <select id="department" name="department" required>
                        <option value="">Select Department</option>
                        <option value="CITE">CITE</option>
                        <option value="CEA">CEA</option>
                        <option value="CAS">CAS</option>
                        <option value="CMA">CMA</option>
                        <option value="CCJE">CCJE</option>
                    </select>
                </div>
            </div>

            <div class="form-row">
  <div class="form-group">
    <label for="username">Email Address <span style="color: red;">*</span></label>
    <input type="text" id="username" name="username" placeholder="Enter Phinma Email" required>
    <small id="emailError" style="color: red; display: none;">
      Please use a valid PHINMA email (e.g., firstname.lastname.up@phinmaed.com)
    </small>
  </div>
</div>
            <div class="form-row">
                <div class="form-group">
                    <label for="password">Password <span style="color: red;">*</span></label>
                    <div class="password-container">
                        <input type="password" id="password" name="password" placeholder="Create a password" required>
                    </div>
                    <div class="password-strength" id="passwordStrength"></div>
                </div>
            </div>

             <div class="password-options">
                <div class="options show-pass">
                    <input type="checkbox" id="show-pass" name="show-pass">
                    <label for="show-pass">Show Password</label>
                </div>
            </div>

                <div class="form-row">
        <div class="form-group">
            <label for="confirm_password">Confirm Password <span style="color: red;">*</span></label>
            <div class="password-container">
                <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm your password" required>
            </div>
        </div>
    </div>

            <button type="submit" class="create-account-button" id="createAccountButton">CREATE ACCOUNT</button>
            </form>
            
            <div class="login-section">
                <p class="login-text">Already have an account?</p>
                <a href="login.php" class="login-link">Login Here</a>
    </div>
        
        <div class="footer">
            MainTix.com
        </div>
    </div>

    <script src="./dist/database/register.php"></script>
    <script src="./dist/assets/js/register.js"></script>

</body>
</html>