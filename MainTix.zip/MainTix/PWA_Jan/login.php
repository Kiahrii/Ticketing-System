<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="./dist/assets/css/login.css">
</head>

<body>
    <div class="login-container">
        <div class="logo">MainTix</div>

        <form id="loginForm" action="./dist/database/signin.php" method="POST">
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="text" id="email" name="username" placeholder="Enter your PHINMA Email Address" required>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <div class="password-container">
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                </div>
            </div>

            <div class="password-options">
                <div class="options show-pass">
                    <input type="checkbox" id="show-pass" name="show-pass">
                    <label for="show-pass">Show Password</label>
                </div>
            </div>

            <div class="options">
                <div class="remember-me">
                    <input type="checkbox" id="remember" name="remember">
                    <label for="remember">Remember me</label>
                </div>
                <a href="#" class="forgot-password" id="forgotPasswordLink">Forgot Password?</a>
            </div>

            <button type="submit" class="login-button" id="loginButton">LOGIN</button>
        </form>

        <div class="create-account-section">
            <p class="create-account-text">Don't have an account yet?</p>
            <a href="signup.php" class="create-account-link">Create Account</a>
        </div>

        <div class="footer">
            MainTix.com
        </div>
    </div>

    <div class="modal" action="./dist/database/signin.php" id="forgotPasswordModal">
        <div class="modal-content">
            <h3>Reset Your Password</h3>
            <p>Enter your email address and we'll send you instructions to reset your password.</p>
            <div class="form-group">
                <label for="resetEmail">Email Address</label>
                <input type="email" id="resetEmail" placeholder="Enter your PHINMA email">
                <div class="error-message" id="emailError" style="display: none;"></div>
                <div class="success-message" id="emailSuccess" style="display: none;">Reset instructions sent to your email!</div>
            </div>
            <div class="modal-buttons">
                <button type="button" class="modal-button modal-cancel" id="cancelReset">Cancel</button>
                <button type="button" class="modal-button modal-submit" id="submitReset">Send Instructions</button>
            </div>
        </div>
    </div>

    <script src="dist/assets/js/login.js"></script>
</body>

</html>